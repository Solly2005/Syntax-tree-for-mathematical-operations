#include "ParseTree.h"
#include <stack>
#include <cctype>
#include <sstream>
#include <stdexcept>
#include <stack>
ParseTree::ParseTree() : root(nullptr) {}

ParseTree::~ParseTree() {
    destroyTree(root);
}
    // Removed invalid function definition

void ParseTree::destroyTree(Node* node) {
    if (!node) return;
    destroyTree(node->getLeft());
    destroyTree(node->getRight());
    delete node;
}
bool ParseTree::isValidExpression(const std::string& expr) {
    std::stack<char> balance;
    for (size_t i = 0; i < expr.length(); ++i) {
        if (expr[i] == '(') {
            balance.push('(');
        } else if (expr[i] == ')') {
            if (balance.empty()) {
                return false;
            } else {
                balance.pop();
            }
        }
    }
    return balance.empty();
}
Node* ParseTree::getRoot() {
    return root;
}

void ParseTree::build(const std::string& expr) {
    std::string postfix = infixToPostfix(expr);
    root = buildTreeFromExpression(postfix);
}

Node* ParseTree::buildTreeFromExpression(const std::string& postfix) {
    std::stack<Node*> st;

    for (size_t i = 0; i < postfix.length(); ++i) {
        char c = postfix[i];
        if (std::isspace(c)) continue;

        if (std::isdigit(c)) {
            std::string num(1, c);
            while (i + 1 < postfix.length() && std::isdigit(postfix[i + 1])) {
                num += postfix[++i];
            }
            st.push(new Node(num));
        } else if (isOperator(c)) {
            if (st.size() < 2) throw std::runtime_error("Invalid expression");
            Node* right = st.top(); st.pop();
            Node* left = st.top(); st.pop();
            st.push(new Node(std::string(1, c), left, right));
        }
    }

    return st.empty() ? nullptr : st.top();
}

std::string ParseTree::infixToPostfix(const std::string& expr) {
    std::stack<char> ops;
    std::string output;

    for (size_t i = 0; i < expr.length(); ++i) {
        char c = expr[i];
        if (std::isspace(c)) continue;

        if (std::isdigit(c)) {
            output += c;
            while (i + 1 < expr.length() && std::isdigit(expr[i + 1])) {
                output += expr[++i];
            }
            output += ' ';
        } else if (c == '(') {
            ops.push(c);
        } else if (c == ')') {
            while (!ops.empty() && ops.top() != '(') {
                output += ops.top();
                output += ' ';
                ops.pop();
            }
            if (!ops.empty() && ops.top() == '(') ops.pop();
        } else if (isOperator(c)) {
            while (!ops.empty() && getPrecedence(ops.top()) >= getPrecedence(c)) {
                output += ops.top();
                output += ' ';
                ops.pop();
            }
            ops.push(c);
        }
    }

    while (!ops.empty()) {
        output += ops.top();
        output += ' ';
        ops.pop();
    }

    return output;
}

bool ParseTree::isOperator(char c) {
    return c == '+' || c == '-' || c == '*' || c == '/';
}

int ParseTree::getPrecedence(char op) {
    if (op == '+' || op == '-') return 1;
    if (op == '*' || op == '/') return 2;
    return 0;
}

double ParseTree::evaluate() {
    if (!root) throw std::runtime_error("No tree built to evaluate.");
    return evaluate(root);
}

double ParseTree::evaluate(Node* node) {
    if (!node) return 0.0;

    std::string val = node->getValue();
    if (!isOperator(val[0]) || val.length() > 1) {
        return std::stod(val);
    }

    double left = evaluate(node->getLeft());
    double right = evaluate(node->getRight());

    switch (val[0]) {
        case '+': return left + right;
        case '-': return left - right;
        case '*': return left * right;
        case '/':
            if (right == 0) throw std::runtime_error("Division by zero");
            return left / right;
        default: throw std::runtime_error("Unknown operator");
    }
}
