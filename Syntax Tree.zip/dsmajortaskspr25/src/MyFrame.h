#ifndef MYFRAME_H
#define MYFRAME_H

#include <wx/wx.h>
#include "ParseTree.h"
#include "TreePanel.h"

class MyFrame : public wxFrame {
public:
    MyFrame(const wxString& title);

private:
    // UI Elements
    wxTextCtrl* m_input;
    wxButton* m_parseButton;
    wxButton* m_themeButton;
    wxButton* m_zoomInButton;
    wxButton* m_zoomOutButton;
    wxButton* m_resetZoomButton;
    wxPanel* m_topPanel;
    TreePanel* m_treePanel;

    // Theme State
    bool m_darkTheme;

    // Event Handlers
    void OnParse(wxCommandEvent& event);
    void OnToggleTheme(wxCommandEvent& event);
    void OnZoomIn(wxCommandEvent& event);
    void OnZoomOut(wxCommandEvent& event);
    void OnResetZoom(wxCommandEvent& event);
    void ApplyTheme();
};

#endif
