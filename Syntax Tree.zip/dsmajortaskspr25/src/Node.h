#ifndef NODE_H
#define NODE_H

#include <string>

class Node {
public:
    std::string value;
    Node* left;
    Node* right;

    // Constructor
    Node(const std::string& val, Node* l = nullptr, Node* r = nullptr);

    // Destructor
    ~Node();
    void setLeft(Node* l) ;
    void setRight(Node* r) ;
    Node* getLeft() const ;
    Node* getRight() const ;
    std::string getValue() const ;
    void setValue(const std::string& val) ;
};

#endif // NODE_H
