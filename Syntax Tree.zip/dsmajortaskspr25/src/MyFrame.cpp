#include "MyFrame.h"

MyFrame::MyFrame(const wxString& title)
    : wxFrame(nullptr, wxID_ANY, title, wxDefaultPosition, wxSize(450, 700)),
      m_darkTheme(false)
{
    // Input Panel (Top)
    m_topPanel = new wxPanel(this);
    m_input = new wxTextCtrl(m_topPanel, wxID_ANY, "", wxDefaultPosition, wxSize(280, 35));
    m_parseButton = new wxButton(m_topPanel, wxID_ANY, "Parse");

    wxBoxSizer* topSizer = new wxBoxSizer(wxHORIZONTAL);
    topSizer->Add(m_input, 1, wxALL | wxEXPAND, 6);
    topSizer->Add(m_parseButton, 0, wxALL, 6);
    m_topPanel->SetSizer(topSizer);

    // Tree Panel (Middle)
    m_treePanel = new TreePanel(this);
    m_treePanel->SetMinSize(wxSize(-1, 500));

    // Control Buttons (Bottom)
    m_themeButton = new wxButton(this, wxID_ANY, "Toggle Theme");
    m_zoomInButton = new wxButton(this, wxID_ANY, "Zoom In");
    m_zoomOutButton = new wxButton(this, wxID_ANY, "Zoom Out");
    m_resetZoomButton = new wxButton(this, wxID_ANY, "Reset Zoom");

    wxBoxSizer* buttonSizer = new wxBoxSizer(wxHORIZONTAL);
    buttonSizer->Add(m_themeButton, 1, wxALL, 4);
    buttonSizer->Add(m_zoomInButton, 1, wxALL, 4);
    buttonSizer->Add(m_zoomOutButton, 1, wxALL, 4);
    buttonSizer->Add(m_resetZoomButton, 1, wxALL, 4);

    // Main Layout
    wxBoxSizer* mainSizer = new wxBoxSizer(wxVERTICAL);
    mainSizer->Add(m_topPanel, 0, wxEXPAND | wxALL, 4);
    mainSizer->Add(m_treePanel, 1, wxEXPAND | wxLEFT | wxRIGHT, 8);
    mainSizer->Add(buttonSizer, 0, wxEXPAND | wxALL, 4);

    SetSizerAndFit(mainSizer);

    // Bind Events
    m_parseButton->Bind(wxEVT_BUTTON, &MyFrame::OnParse, this);
    m_themeButton->Bind(wxEVT_BUTTON, &MyFrame::OnToggleTheme, this);
    m_zoomInButton->Bind(wxEVT_BUTTON, &MyFrame::OnZoomIn, this);
    m_zoomOutButton->Bind(wxEVT_BUTTON, &MyFrame::OnZoomOut, this);
    m_resetZoomButton->Bind(wxEVT_BUTTON, &MyFrame::OnResetZoom, this);

    ApplyTheme();
}

void MyFrame::OnParse(wxCommandEvent& event) {
    wxString input = m_input->GetValue();
    if (input.IsEmpty()) return;

    std::string expr = std::string(input.mb_str());
    ParseTree* tree = new ParseTree();

    // ✅ Validate parentheses before building the tree
    if (!tree->isValidExpression(expr)) {
        wxMessageBox("Invalid expression: parentheses are not balanced.", "Syntax Error", wxOK | wxICON_ERROR);
        delete tree;
        return;
    }

    try {
        tree->build(expr);
        double result = tree->evaluate();
        m_treePanel->SetTree(tree);
        m_treePanel->SetResult(result);
    } catch (...) {
        wxMessageBox("Invalid expression format!", "Parse Error", wxOK | wxICON_ERROR);
        delete tree;
    }
}

void MyFrame::OnToggleTheme(wxCommandEvent& event) {
    m_darkTheme = !m_darkTheme;
    ApplyTheme();
}

void MyFrame::ApplyTheme() {
    wxColour bg = m_darkTheme ? wxColour(20, 20, 20) : wxColour(255, 255, 255);
    wxColour fg = m_darkTheme ? wxColour(240, 240, 240) : wxColour(0, 0, 0);
    wxColour btnColor = m_darkTheme ? wxColour(40, 40, 40) : wxColour(230, 230, 230);
    wxColour btnText = m_darkTheme ? *wxWHITE : *wxBLACK;

    // Set text input field color
    m_topPanel->SetBackgroundColour(bg);
    m_input->SetBackgroundColour(bg);
    m_input->SetForegroundColour(fg);

    m_parseButton->SetBackgroundColour(btnColor);
    m_parseButton->SetForegroundColour(btnText);

    wxWindowList children = GetChildren();
    for (auto it = children.begin(); it != children.end(); ++it) {
        if (auto* btn = dynamic_cast<wxButton*>(*it)) {
            btn->SetBackgroundColour(btnColor);
            btn->SetForegroundColour(btnText);
        }
    }

    m_treePanel->SetTheme(m_darkTheme);
    Refresh();
}


void MyFrame::OnZoomIn(wxCommandEvent& event) {
    m_treePanel->ZoomIn();
}

void MyFrame::OnZoomOut(wxCommandEvent& event) {
    m_treePanel->ZoomOut();
}

void MyFrame::OnResetZoom(wxCommandEvent& event) {
    m_treePanel->ResetZoom();
}
