#ifndef TREEPANEL_H
#define TREEPANEL_H

#include <wx/wx.h>
#include <wx/dcbuffer.h>
#include "ParseTree.h"
#include <map>

class TreePanel : public wxPanel {
public:
    TreePanel(wxWindow* parent);
    void SetTree(ParseTree* tree);
    void SetTheme(bool dark);
    void SetResult(double result);
    void ZoomIn();
    void ZoomOut();
    void ResetZoom();

private:
    ParseTree* m_tree;
    bool m_darkTheme;
    double m_result;
    double m_dx;
    int m_dy;

    std::map<Node*, int> m_nodeXPositions;
    std::map<Node*, wxPoint> m_nodeOffsets;
    Node* m_draggedNode;
    wxPoint m_lastMousePos;

    void OnPaint(wxPaintEvent& evt);
    void OnResize(wxSizeEvent& evt);
    void OnMouseDown(wxMouseEvent& evt);
    void OnMouseMove(wxMouseEvent& evt);
    void OnMouseUp(wxMouseEvent& evt);

    void DrawTree(wxDC& dc);
    void DrawNode(wxDC& dc, Node* node, int depth);
    void CalculateNodePositions(Node* node, int depth, int& currentX);
    int GetTreeDepth(Node* node);

    wxDECLARE_EVENT_TABLE();
};

#endif
