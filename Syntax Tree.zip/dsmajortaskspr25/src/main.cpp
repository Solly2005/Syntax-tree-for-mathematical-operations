#include "MyFrame.h"
#include <wx/app.h>

class MyApp : public wxApp {
public:
    virtual bool OnInit() {
        MyFrame* frame = new MyFrame("Parse Tree GUI");
        frame->Show(true);
        return true;
    }
};

wxIMPLEMENT_APP(MyApp);
