#include "TreePanel.h"
#include <cmath>

TreePanel::TreePanel(wxWindow* parent)
    : wxPanel(parent), m_tree(nullptr), m_darkTheme(false), m_result(0.0),
      m_dx(120), m_dy(70), m_draggedNode(nullptr)
{
    SetBackgroundStyle(wxBG_STYLE_PAINT);
    SetBackgroundColour(wxColour(245, 245, 245));
}

void TreePanel::SetTree(ParseTree* tree) {
    m_tree = tree;
    m_nodeOffsets.clear();
    Refresh();
}

void TreePanel::SetTheme(bool dark) {
    m_darkTheme = dark;
    SetBackgroundColour(dark ? wxColour(30, 30, 30) : wxColour(245, 245, 245));
    Refresh();
}

void TreePanel::SetResult(double result) {
    m_result = result;
    Refresh();
}

void TreePanel::ZoomIn() {
    if (m_dx < 300) m_dx += 20;
    if (m_dy < 150) m_dy += 10;
    Refresh();
}

void TreePanel::ZoomOut() {
    if (m_dx > 40) m_dx -= 20;
    if (m_dy > 40) m_dy -= 10;
    Refresh();
}

void TreePanel::ResetZoom() {
    m_dx = 120;
    m_dy = 70;
    m_nodeOffsets.clear();
    Refresh();
}

void TreePanel::OnResize(wxSizeEvent& evt) {
    Refresh();
    evt.Skip();
}

void TreePanel::OnMouseDown(wxMouseEvent& evt) {
    wxPoint click = evt.GetPosition();
    m_draggedNode = nullptr;

    for (auto& [node, index] : m_nodeXPositions) {
        wxPoint offset = m_nodeOffsets[node];
        int x = (index + 1) * m_dx + offset.x;
        int y = 40 + GetTreeDepth(node) * m_dy + offset.y;

        if ((click.x - x) * (click.x - x) + (click.y - y) * (click.y - y) <= 625) {
            m_draggedNode = node;
            m_lastMousePos = click;
            CaptureMouse();
            break;
        }
    }
}

void TreePanel::OnMouseMove(wxMouseEvent& evt) {
    if (m_draggedNode && evt.Dragging()) {
        wxPoint pos = evt.GetPosition();
        wxPoint& offset = m_nodeOffsets[m_draggedNode];
        offset.x += pos.x - m_lastMousePos.x;
        offset.y += pos.y - m_lastMousePos.y;
        m_lastMousePos = pos;
        Refresh();
    }
}

void TreePanel::OnMouseUp(wxMouseEvent& evt) {
    if (HasCapture()) ReleaseMouse();
    m_draggedNode = nullptr;
}

void TreePanel::OnPaint(wxPaintEvent& evt) {
    wxAutoBufferedPaintDC dc(this);
    dc.Clear();
    DrawTree(dc);
}

void TreePanel::DrawTree(wxDC& dc) {
    wxColour bg = m_darkTheme ? wxColour(30, 30, 30) : wxColour(245, 245, 245);
    wxColour textColor = m_darkTheme ? *wxWHITE : *wxBLACK;

    dc.SetBackground(wxBrush(bg));
    dc.Clear();
    dc.SetTextForeground(textColor);
    dc.SetFont(wxFont(12, wxFONTFAMILY_SWISS, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_BOLD));

    if (!m_tree || !m_tree->getRoot()) return;

    m_nodeXPositions.clear();
    int currentX = 0;
    CalculateNodePositions(m_tree->getRoot(), 0, currentX);
    DrawNode(dc, m_tree->getRoot(), 0);

    wxString resultStr = wxString::Format("Result: %.2f", m_result);
    dc.DrawText(resultStr, 20, GetSize().GetHeight() - 30);
}

void TreePanel::CalculateNodePositions(Node* node, int depth, int& currentX) {
    if (!node) return;
    CalculateNodePositions(node->getLeft(), depth + 1, currentX);
    m_nodeXPositions[node] = currentX++;
    CalculateNodePositions(node->getRight(), depth + 1, currentX);
}

int TreePanel::GetTreeDepth(Node* node) {
    if (!node) return 0;
    return 1 + std::max(GetTreeDepth(node->getLeft()), GetTreeDepth(node->getRight()));
}

void TreePanel::DrawNode(wxDC& dc, Node* node, int depth) {
    if (!node) return;

    int spacing = m_dx;
    wxPoint offset = m_nodeOffsets[node];
    int x = (m_nodeXPositions[node] + 1) * spacing + offset.x;
    int y = 40 + depth * m_dy + offset.y;
    int radius = 25;

    // 🟠 Flat circle fill
    wxColour fillColor = m_darkTheme ? wxColour(80, 140, 240) : wxColour(110, 160, 255);
    wxColour borderColor = m_darkTheme ? *wxWHITE : *wxBLACK;

    dc.SetBrush(wxBrush(fillColor));
    dc.SetPen(wxPen(borderColor, 2));
    dc.DrawCircle(x, y, radius);

    // 🟡 Node label (value)
    wxString label = node->getValue();
    wxSize textSize = dc.GetTextExtent(label);
    dc.SetTextForeground(borderColor);
    dc.DrawText(label, x - textSize.GetWidth() / 2, y - textSize.GetHeight() / 2);

    // 🔗 Branch lines
    dc.SetPen(wxPen(borderColor, 1));

    if (node->getLeft()) {
        wxPoint offsetL = m_nodeOffsets[node->getLeft()];
        int xL = (m_nodeXPositions[node->getLeft()] + 1) * spacing + offsetL.x;
        int yL = 40 + (depth + 1) * m_dy + offsetL.y;
        dc.DrawLine(x, y + radius, xL, yL - radius);
        DrawNode(dc, node->getLeft(), depth + 1);
    }

    if (node->getRight()) {
        wxPoint offsetR = m_nodeOffsets[node->getRight()];
        int xR = (m_nodeXPositions[node->getRight()] + 1) * spacing + offsetR.x;
        int yR = 40 + (depth + 1) * m_dy + offsetR.y;
        dc.DrawLine(x, y + radius, xR, yR - radius);
        DrawNode(dc, node->getRight(), depth + 1);
    }
}


// Event table
wxBEGIN_EVENT_TABLE(TreePanel, wxPanel)
    EVT_PAINT(TreePanel::OnPaint)
    EVT_SIZE(TreePanel::OnResize)
    EVT_LEFT_DOWN(TreePanel::OnMouseDown)
    EVT_LEFT_UP(TreePanel::OnMouseUp)
    EVT_MOTION(TreePanel::OnMouseMove)
wxEND_EVENT_TABLE()
