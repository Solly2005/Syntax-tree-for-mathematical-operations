#include "Node.h"

// Constructor definition
Node::Node(const std::string& val, Node* l, Node* r)
    : value(val), left(l), right(r) {}

// Destructor definition
Node::~Node() {
    delete left;
    delete right;
    value = '\0';
}
void Node::setLeft(Node* l) {
    left = l;
}
void Node::setRight(Node* r) {
    right = r;
}
Node* Node::getLeft() const {
    return left;
}
Node* Node::getRight() const {
    return right;
}
std::string Node::getValue() const {
    return value;
}
void Node::setValue(const std::string& val) {
    value = val;
}
