#ifndef PARSETREE_H
#define PARSETREE_H

#include <string>
#include "Node.h"
#include <stack>
class ParseTree {
public:
    ParseTree();
    ~ParseTree();
    std::string expr;
    void build(const std::string& expression); // Build from infix expression
    double evaluate();                         // Evaluate the expression
    Node* getRoot();                           // Access root for drawing
    bool isValidExpression(const std::string& expr);
    std::stack<char> getbalance();
    void setbalance();
private:
    Node* root;
    std::stack<char> balance;
    Node* buildTreeFromExpression(const std::string& postfix); // Builds from postfix
    std::string infixToPostfix(const std::string& expr);       // Converts infix to postfix
    bool isOperator(char c);
    int getPrecedence(char op);
    double evaluate(Node* node);               // Recursive evaluation
    void destroyTree(Node* node);              // Frees memory
};

#endif
